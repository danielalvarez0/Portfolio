﻿
/**********************************************************************
 *  ps0-readme document                                                 
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Daniel Alvarez

Operating system you're using (Linux, OS X, or Windows): Linux virtual machine (virtualBox)

If Windows, which solution?: 
 
Text editor or IDE you're using: gedit
 
Hours to complete assignment (optional):

/**********************************************************************
 *  List some information (optionally) to help me get to know you.
	I am: a Junior
		 a cs major
		 a fan of fantasy/sci-fi books
		 
**********************************************************************/

Did you take Computing I at UML?
	 No

 - If yes, who was your instructor?

 - If no, where did you transfer from?
  	Case Western Reserve University


/**********************************************************************
 *  Part of Assignment 0 is to join the course Google group.
 *  Did you do this?:
	 I have not joined the Google group because as of Sunday 9/10 2:10pm I have not received any instructions on joining the group (aka no one has told me, either via email, in the syllabus, or on blackboard how to find the group.
 **********************************************************************/



/**********************************************************************
 *  Another part of Assignment 0 is to read the information on Academic
 *  Integrity at the course home page.
 *
 *  If you haven't done this, please do so now.
 *
 *  Follow the link to the University policy on Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.


	I think that (other than (a)) (f) is most likely to apply to this class. I think a would be most likely because the temptation to copy code directly from a reference book or an online source can be extremely tempting and also very easy to do (ctrl-c, followed by ctrl-v). Given that (a) was excluded I think that (f)is most likely to apply because of how common it is to ask a classmate for help if you are stuck on a coding assignment. Helping a classmate is allowed, but the most obvious way to help someone (at least the most obvious to me) is to look at their code and compare it to your own or reference your own as you read it. While doing this it is extremely easy to let the person you are helping see your code and they then have the option of just directly copying your work. 
 **********************************************************************/



/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else: None
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
		I encountered no serious problems in this assignment.		
**********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

